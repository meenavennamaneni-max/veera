export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

export type RobotCommand =
  | 'FORWARD'
  | 'BACK'
  | 'LEFT'
  | 'RIGHT'
  | 'STOP'
  | 'INTRO'
  | 'USES'
  | 'HAND'
  | 'SPEAK';

export interface LogEntry {
  id: string;
  timestamp: Date;
  type: 'command' | 'response' | 'error' | 'info' | 'speech';
  message: string;
}

export interface VoiceHistoryEntry {
  id: string;
  timestamp: Date;
  text: string;
  type: 'custom' | 'intro' | 'uses' | 'system';
}

export interface RobotState {
  connectionStatus: ConnectionStatus;
  batteryLevel: number;
  currentActivity: string;
  isMoving: boolean;
  isSpeaking: boolean;
  isHandMoving: boolean;
  lastCommand: string;
  signalStrength: number;
  uptime: number;
}

export interface BluetoothServiceConfig {
  serviceUUID: string;
  characteristicUUID: string;
  deviceName: string;
}
