import { useState, useCallback, useEffect } from 'react';
import { Bot, Zap, Menu, X } from 'lucide-react';
import { useBluetooth } from './hooks/useBluetooth';
import { useTTS } from './hooks/useTTS';
import type { RobotCommand, VoiceHistoryEntry } from './types/robot';

import RobotAvatar from './components/RobotAvatar';
import BluetoothPanel from './components/BluetoothPanel';
import MovementControls from './components/MovementControls';
import ActionButtons from './components/ActionButtons';
import VoicePanel from './components/VoicePanel';
import StatusPanel from './components/StatusPanel';
import CommandLog from './components/CommandLog';
import IntroPanel from './components/IntroPanel';
import UsesPanel from './components/UsesPanel';

const INTRO_TEXT = `Greetings! I am Veera Bot, your advanced personal robot assistant. I stand 2 feet tall and am built with a futuristic square-body mechanical design. I am powered by an ESP32 microcontroller with Bluetooth Low Energy connectivity. I can move in all four directions, speak custom messages through my built-in speaker, and move my robotic arms on command. I am Veera Bot, and I am at your service!`;

const USES_TEXT = `Veera Bot capabilities: Navigation — omnidirectional movement with precision motor control. Voice Communication — custom TTS messages and announcements. Arm Control — robotic arm actuation with wave and gesture sequences. Remote Control — full Bluetooth BLE control via ESP32. Autonomous Routines — pre-programmed demo sequences. Education and demonstration for STEM learning.`;

export default function App() {
  const bluetooth = useBluetooth();
  const tts = useTTS();

  const [activeCmd, setActiveCmd] = useState<RobotCommand | null>(null);
  const [activeAction, setActiveAction] = useState<string | null>(null);
  const [isMoving, setIsMoving] = useState(false);
  const [isHandMoving, setIsHandMoving] = useState(false);
  const [lastCommand, setLastCommand] = useState('');
  const [commandCount, setCommandCount] = useState(0);
  const [voiceHistory, setVoiceHistory] = useState<VoiceHistoryEntry[]>([]);
  const [showIntro, setShowIntro] = useState(false);
  const [showUses, setShowUses] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const addVoiceHistory = useCallback((text: string, type: VoiceHistoryEntry['type']) => {
    setVoiceHistory((prev) => [
      {
        id: Date.now().toString() + Math.random(),
        timestamp: new Date(),
        text,
        type,
      },
      ...prev.slice(0, 49),
    ]);
  }, []);

  const handleCommand = useCallback(
    async (cmd: RobotCommand) => {
      setActiveCmd(cmd);
      setLastCommand(cmd);
      setCommandCount((c) => c + 1);

      const moveCmds: RobotCommand[] = ['FORWARD', 'BACK', 'LEFT', 'RIGHT'];
      if (moveCmds.includes(cmd)) {
        setIsMoving(true);
        setTimeout(() => setIsMoving(false), 600);
      } else {
        setIsMoving(false);
      }

      await bluetooth.sendCommand(cmd);
      setTimeout(() => setActiveCmd(null), 300);
    },
    [bluetooth]
  );

  const handleIntroduction = useCallback(async () => {
    setActiveAction('intro');
    setLastCommand('INTRODUCTION');
    setCommandCount((c) => c + 1);
    addVoiceHistory(INTRO_TEXT, 'intro');
    tts.speak(INTRO_TEXT, 0.9, 0.8);
    await bluetooth.sendCommand('INTRO');
    setShowIntro(true);
    setActiveAction(null);
  }, [bluetooth, tts, addVoiceHistory]);

  const handleUses = useCallback(async () => {
    setActiveAction('uses');
    setLastCommand('USES');
    setCommandCount((c) => c + 1);
    addVoiceHistory(USES_TEXT, 'uses');
    tts.speak(USES_TEXT, 0.9, 0.8);
    await bluetooth.sendCommand('USES');
    setShowUses(true);
    setActiveAction(null);
  }, [bluetooth, tts, addVoiceHistory]);

  const handleHandMovement = useCallback(async () => {
    setActiveAction('hand');
    setIsHandMoving(true);
    setLastCommand('HAND MOVEMENT');
    setCommandCount((c) => c + 1);
    await bluetooth.sendCommand('HAND');
    setTimeout(() => {
      setIsHandMoving(false);
      setActiveAction(null);
    }, 3000);
  }, [bluetooth]);

  const handleSpeak = useCallback(
    async (text: string) => {
      if (!text.trim()) return;
      setLastCommand(`SPEAK: "${text.substring(0, 30)}..."`);
      setCommandCount((c) => c + 1);
      addVoiceHistory(text, 'custom');
      tts.speak(text);
      await bluetooth.sendCommand('SPEAK', text);
    },
    [bluetooth, tts, addVoiceHistory]
  );

  const handleIntroSpeak = useCallback(
    (text: string) => {
      addVoiceHistory(text, 'intro');
      tts.speak(text, 0.9, 0.8);
    },
    [tts, addVoiceHistory]
  );

  const handleUsesSpeak = useCallback(
    (text: string) => {
      addVoiceHistory(text, 'uses');
      tts.speak(text, 0.9, 0.8);
    },
    [tts, addVoiceHistory]
  );

  const isConnected = bluetooth.status === 'connected';

  return (
    <div className="min-h-screen grid-bg relative overflow-x-hidden">
      {/* Background glow effects */}
      <div
        className="fixed top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full pointer-events-none z-0"
        style={{
          background: 'radial-gradient(ellipse, rgba(255,215,0,0.05) 0%, transparent 65%)',
          filter: 'blur(50px)',
        }}
      />
      <div
        className="fixed top-1/2 left-0 -translate-y-1/2 w-[500px] h-[600px] pointer-events-none z-0"
        style={{
          background: 'radial-gradient(ellipse, rgba(0,100,255,0.03) 0%, transparent 70%)',
          filter: 'blur(60px)',
        }}
      />
      <div
        className="fixed bottom-0 right-0 w-[600px] h-[500px] pointer-events-none z-0"
        style={{
          background: 'radial-gradient(ellipse, rgba(120,40,255,0.04) 0%, transparent 70%)',
          filter: 'blur(60px)',
        }}
      />
      {/* Horizontal light line */}
      <div
        className="fixed top-0 left-0 right-0 h-px pointer-events-none z-50"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(255,215,0,0.4) 30%, rgba(255,215,0,0.4) 70%, transparent)' }}
      />

      {/* Overlay panels */}
      {showIntro && (
        <IntroPanel
          isConnected={isConnected}
          isSpeaking={tts.isSpeaking}
          onSpeak={handleIntroSpeak}
          onClose={() => {
            setShowIntro(false);
            tts.stopSpeaking();
          }}
        />
      )}
      {showUses && (
        <UsesPanel
          isConnected={isConnected}
          isSpeaking={tts.isSpeaking}
          onSpeak={handleUsesSpeak}
          onClose={() => {
            setShowUses(false);
            tts.stopSpeaking();
          }}
        />
      )}

      {/* ===== HEADER ===== */}
      <header className="sticky top-0 z-40 border-b border-yellow-500/15" style={{ background: 'rgba(5,5,12,0.97)', backdropFilter: 'blur(24px)', boxShadow: '0 4px 30px rgba(0,0,0,0.5), 0 1px 0 rgba(255,215,0,0.08)' }}>
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6">
          <div className="flex items-center h-16 gap-4">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div
                className="relative w-9 h-9 rounded-lg overflow-hidden flex items-center justify-center border border-yellow-500/40 bg-yellow-500/10"
                style={{ boxShadow: '0 0 15px rgba(255,215,0,0.2)' }}
              >
                <img
                  src="/logo.png"
                  alt="Veera Bot logo"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
                {isConnected && (
                  <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-gray-900 animate-pulse" />
                )}
              </div>
              <div>
                <div className="text-base font-black text-white tracking-wider font-mono leading-none">
                  VEERA <span className="text-yellow-400">BOT</span>
                </div>
                <div className="text-xs text-gray-500 font-mono leading-none mt-0.5 hidden sm:block">CONTROL CENTER</div>
              </div>
            </div>

            {/* Center status bar */}
            <div className="hidden lg:flex items-center gap-6 mx-auto">
              {/* Connection indicator */}
              <div className={`flex items-center gap-2 px-4 py-1.5 rounded-full border text-xs font-mono font-bold ${
                isConnected
                  ? 'border-green-500/30 bg-green-500/10 text-green-400'
                  : bluetooth.status === 'connecting'
                  ? 'border-yellow-500/30 bg-yellow-500/10 text-yellow-400 animate-pulse'
                  : 'border-gray-700 bg-gray-800/30 text-gray-500'
              }`}>
                <div className={`w-2 h-2 rounded-full ${
                  isConnected ? 'bg-green-400' : bluetooth.status === 'connecting' ? 'bg-yellow-400' : 'bg-gray-600'
                } ${isConnected || bluetooth.status === 'connecting' ? 'animate-pulse' : ''}`} />
                {isConnected ? 'VEERA BOT CONNECTED' : bluetooth.status === 'connecting' ? 'CONNECTING...' : 'NO DEVICE'}
              </div>

              {/* Activity indicators */}
              {isConnected && (
                <div className="flex items-center gap-4 text-xs font-mono">
                  <span className={`flex items-center gap-1.5 ${isMoving ? 'text-yellow-400' : 'text-gray-600'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${isMoving ? 'bg-yellow-400 animate-pulse' : 'bg-gray-700'}`} />
                    MOTION
                  </span>
                  <span className={`flex items-center gap-1.5 ${tts.isSpeaking ? 'text-purple-400' : 'text-gray-600'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${tts.isSpeaking ? 'bg-purple-400 animate-pulse' : 'bg-gray-700'}`} />
                    AUDIO
                  </span>
                  <span className={`flex items-center gap-1.5 ${isHandMoving ? 'text-orange-400' : 'text-gray-600'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${isHandMoving ? 'bg-orange-400 animate-pulse' : 'bg-gray-700'}`} />
                    ARMS
                  </span>
                </div>
              )}
            </div>

            {/* Right: time + mobile menu */}
            <div className="flex items-center gap-3 ml-auto">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-xs font-mono font-bold text-white">
                  {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
                <span className="text-xs font-mono text-gray-600">
                  {currentTime.toLocaleDateString([], { month: 'short', day: '2-digit', year: 'numeric' })}
                </span>
              </div>

              <div className="flex items-center gap-1">
                <div className="w-px h-6 bg-gray-700 hidden sm:block" />
                <div className="flex items-center gap-1">
                  <Zap size={12} className="text-yellow-400" />
                  <span className="text-xs font-mono text-yellow-400 font-bold hidden sm:inline">ESP32</span>
                </div>
              </div>

              {/* Mobile menu toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg border border-gray-700 text-gray-400 hover:text-white transition-all"
              >
                {mobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile dropdown menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden sticky top-16 z-30 border-b border-yellow-500/10" style={{ background: 'rgba(8,8,16,0.97)' }}>
          <div className="p-4 space-y-3">
            <div className={`flex items-center gap-2 text-xs font-mono ${isConnected ? 'text-green-400' : 'text-gray-500'}`}>
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400 animate-pulse' : 'bg-gray-600'}`} />
              {isConnected ? 'VEERA BOT CONNECTED' : 'NOT CONNECTED'}
            </div>
            {isConnected && (
              <div className="flex gap-4 text-xs font-mono">
                <span className={isMoving ? 'text-yellow-400' : 'text-gray-600'}>● MOTION</span>
                <span className={tts.isSpeaking ? 'text-purple-400' : 'text-gray-600'}>● AUDIO</span>
                <span className={isHandMoving ? 'text-orange-400' : 'text-gray-600'}>● ARMS</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===== MAIN CONTENT ===== */}
      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 py-6 relative z-10">

        {/* Page title row */}
        <div className="mb-6">
          <div className="flex items-start sm:items-center gap-4 flex-col sm:flex-row">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                {/* Decorative bracket */}
                <div className="hidden sm:block w-1 h-10 rounded-full" style={{ background: 'linear-gradient(180deg, #FFD700, rgba(255,215,0,0.1))' }} />
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl sm:text-3xl font-black text-white tracking-wider font-mono leading-none">
                      ROBOT <span style={{ color: '#FFD700', textShadow: '0 0 20px rgba(255,215,0,0.4)' }}>CONTROL</span> DASHBOARD
                    </h1>
                  </div>
                  <p className="text-xs sm:text-sm text-gray-500 font-mono mt-1">
                    VEERA BOT Autonomous Control Interface v2.0 — ESP32 Bluetooth LE
                  </p>
                </div>
              </div>
            </div>
            {/* Status chips */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono font-bold ${
                isConnected ? 'border-green-500/30 bg-green-500/10 text-green-400' : 'border-gray-700 bg-gray-800/30 text-gray-500'
              }`}>
                <div className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-green-400 animate-pulse' : 'bg-gray-600'}`} />
                {isConnected ? 'CONNECTED' : 'DISCONNECTED'}
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-yellow-500/20 bg-yellow-500/5 text-xs font-mono font-bold text-yellow-600">
                ESP32 BLE
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-700 bg-gray-800/30 text-xs font-mono text-gray-500">
                {commandCount} cmds
              </div>
            </div>
          </div>
          {/* Horizontal rule */}
          <div className="mt-4 h-px" style={{ background: 'linear-gradient(90deg, rgba(255,215,0,0.3), rgba(255,215,0,0.1) 40%, transparent)' }} />
        </div>

        {/* ===== DESKTOP LAYOUT ===== */}
        <div className="hidden lg:grid grid-cols-[300px_1fr_300px] xl:grid-cols-[320px_1fr_320px] gap-5">

          {/* ---- LEFT COLUMN ---- */}
          <div className="flex flex-col gap-5">
            {/* Robot avatar */}
            <div className="glass-panel rounded-xl p-4 flex flex-col items-center panel-corners" style={{ background: 'linear-gradient(145deg, rgba(14,14,28,0.98), rgba(8,8,18,0.99))' }}>
              <div className="flex items-center gap-2 w-full border-b border-yellow-500/10 pb-3 mb-4">
                <Bot size={16} className="text-yellow-400" />
                <span className="text-yellow-400 text-sm font-bold tracking-widest uppercase font-mono">VEERA BOT</span>
                <div className="ml-auto flex items-center gap-1.5">
                  <span className="text-xs text-gray-600 font-mono">v2.0</span>
                  <div className="w-1 h-4 bg-gray-700 rounded-full" />
                  <span className="text-xs font-mono font-bold" style={{ color: isConnected ? '#00ff88' : '#666' }}>
                    {isConnected ? 'LIVE' : 'IDLE'}
                  </span>
                </div>
              </div>
              <RobotAvatar
                status={bluetooth.status}
                isSpeaking={tts.isSpeaking}
                isMoving={isMoving}
                isHandMoving={isHandMoving}
              />
            </div>

            {/* Bluetooth */}
            <BluetoothPanel
              status={bluetooth.status}
              error={bluetooth.error}
              isBluetoothAvailable={bluetooth.isBluetoothAvailable}
              onConnect={bluetooth.connect}
              onDisconnect={bluetooth.disconnect}
              onReconnect={bluetooth.reconnect}
            />
          </div>

          {/* ---- CENTER COLUMN ---- */}
          <div className="flex flex-col gap-5">
            {/* Movement + Actions side by side */}
            <div className="grid grid-cols-2 gap-5">
              <MovementControls
                isConnected={isConnected}
                onCommand={handleCommand}
                activeCmd={activeCmd}
              />
              <ActionButtons
                isConnected={isConnected}
                isSpeaking={tts.isSpeaking}
                onCommand={handleCommand}
                onIntroduction={handleIntroduction}
                onUses={handleUses}
                onHandMovement={handleHandMovement}
                onStopSpeaking={tts.stopSpeaking}
                activeAction={activeAction}
              />
            </div>

            {/* Voice Panel */}
            <VoicePanel
              isConnected={isConnected}
              isSpeaking={tts.isSpeaking}
              history={voiceHistory}
              onSpeak={handleSpeak}
              onClearHistory={() => setVoiceHistory([])}
            />

            {/* Command log */}
            <CommandLog logs={bluetooth.logs} onClear={bluetooth.clearLogs} />
          </div>

          {/* ---- RIGHT COLUMN ---- */}
          <div className="flex flex-col gap-5">
            {/* Status Panel */}
            <StatusPanel
              status={bluetooth.status}
              isSpeaking={tts.isSpeaking}
              isMoving={isMoving}
              isHandMoving={isHandMoving}
              lastCommand={lastCommand}
              commandCount={commandCount}
            />

            {/* Quick info card */}
            <div className="glass-panel rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 border-b border-yellow-500/10 pb-3">
                <span className="text-yellow-400 text-sm font-bold tracking-widest uppercase font-mono">Quick Guide</span>
              </div>
              <div className="space-y-2.5 text-xs font-mono">
                {[
                  { step: '1', text: 'Press CONNECT ROBOT to pair via Bluetooth', color: 'text-yellow-400' },
                  { step: '2', text: 'Use arrow buttons to move VEERA BOT', color: 'text-blue-400' },
                  { step: '3', text: 'Press INTRODUCTION to hear the robot intro', color: 'text-purple-400' },
                  { step: '4', text: 'Press USES to see robot capabilities', color: 'text-cyan-400' },
                  { step: '5', text: 'Press HAND MOVEMENT to activate arms', color: 'text-orange-400' },
                  { step: '6', text: 'Type a message and press SPEAK', color: 'text-green-400' },
                ].map(({ step, text, color }) => (
                  <div key={step} className="flex items-start gap-2.5">
                    <span className={`shrink-0 w-5 h-5 rounded flex items-center justify-center text-xs font-black border ${color} border-current bg-current/10`}>
                      {step}
                    </span>
                    <span className="text-gray-400 leading-relaxed">{text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* ESP32 Command Table */}
            <div className="glass-panel rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 border-b border-yellow-500/10 pb-3">
                <span className="text-yellow-400 text-sm font-bold tracking-widest uppercase font-mono">BLE Commands</span>
              </div>
              <div className="space-y-1 text-xs font-mono">
                {[
                  { cmd: 'F', desc: 'Move Forward', color: 'text-yellow-400' },
                  { cmd: 'B', desc: 'Move Backward', color: 'text-yellow-400' },
                  { cmd: 'L', desc: 'Turn Left', color: 'text-blue-400' },
                  { cmd: 'R', desc: 'Turn Right', color: 'text-blue-400' },
                  { cmd: 'S', desc: 'Emergency Stop', color: 'text-red-400' },
                  { cmd: 'I', desc: 'Play Introduction', color: 'text-purple-400' },
                  { cmd: 'U', desc: 'Speak Uses', color: 'text-cyan-400' },
                  { cmd: 'H', desc: 'Hand Movement', color: 'text-orange-400' },
                  { cmd: 'T:msg', desc: 'Text-to-Speech', color: 'text-green-400' },
                ].map(({ cmd, desc, color }) => (
                  <div key={cmd} className="flex items-center gap-3 py-1 border-b border-gray-800/50">
                    <span className={`w-12 shrink-0 font-black ${color}`}>{cmd}</span>
                    <span className="text-gray-500">{desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ===== MOBILE / TABLET LAYOUT ===== */}
        <div className="lg:hidden space-y-4">
          {/* Robot + BT row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Robot avatar */}
            <div className="glass-panel rounded-xl p-4 flex flex-col items-center">
              <div className="flex items-center gap-2 w-full border-b border-yellow-500/10 pb-3 mb-3">
                <Bot size={16} className="text-yellow-400" />
                <span className="text-yellow-400 text-sm font-bold tracking-widest uppercase font-mono">VEERA BOT</span>
              </div>
              <RobotAvatar
                status={bluetooth.status}
                isSpeaking={tts.isSpeaking}
                isMoving={isMoving}
                isHandMoving={isHandMoving}
              />
            </div>

            {/* BT + Status stacked */}
            <div className="space-y-4">
              <BluetoothPanel
                status={bluetooth.status}
                error={bluetooth.error}
                isBluetoothAvailable={bluetooth.isBluetoothAvailable}
                onConnect={bluetooth.connect}
                onDisconnect={bluetooth.disconnect}
                onReconnect={bluetooth.reconnect}
              />
            </div>
          </div>

          {/* Status */}
          <StatusPanel
            status={bluetooth.status}
            isSpeaking={tts.isSpeaking}
            isMoving={isMoving}
            isHandMoving={isHandMoving}
            lastCommand={lastCommand}
            commandCount={commandCount}
          />

          {/* Movement + Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <MovementControls
              isConnected={isConnected}
              onCommand={handleCommand}
              activeCmd={activeCmd}
            />
            <ActionButtons
              isConnected={isConnected}
              isSpeaking={tts.isSpeaking}
              onCommand={handleCommand}
              onIntroduction={handleIntroduction}
              onUses={handleUses}
              onHandMovement={handleHandMovement}
              onStopSpeaking={tts.stopSpeaking}
              activeAction={activeAction}
            />
          </div>

          {/* Voice */}
          <VoicePanel
            isConnected={isConnected}
            isSpeaking={tts.isSpeaking}
            history={voiceHistory}
            onSpeak={handleSpeak}
            onClearHistory={() => setVoiceHistory([])}
          />

          {/* Command log */}
          <CommandLog logs={bluetooth.logs} onClear={bluetooth.clearLogs} />
        </div>
      </main>

      {/* ===== FOOTER ===== */}
      <footer className="border-t border-yellow-500/10 mt-8" style={{ background: 'rgba(8,8,16,0.8)' }}>
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-gray-600">
            <span>VEERA BOT Control Center v2.0 — ESP32 BLE Interface</span>
            <div className="flex items-center gap-4">
              <span>BLE UUID: 0xFFE0 / 0xFFE1</span>
              <span className="hidden sm:inline">•</span>
              <span className="text-yellow-500/60">Device: VEERA BOT</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
