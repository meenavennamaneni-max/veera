import { useState, useRef, useCallback } from 'react';
import type { ConnectionStatus, RobotCommand, LogEntry } from '../types/robot';

// ESP32 BLE Service and Characteristic UUIDs
// These should match the UUIDs programmed into your ESP32
const ESP32_SERVICE_UUID = '0000ffe0-0000-1000-8000-00805f9b34fb';
const ESP32_CHARACTERISTIC_UUID = '0000ffe1-0000-1000-8000-00805f9b34fb';
const ROBOT_DEVICE_NAME = 'Veera Bot';

// Command bytes sent to ESP32
const COMMAND_MAP: Record<RobotCommand, string> = {
  FORWARD: 'F',
  BACK: 'B',
  LEFT: 'L',
  RIGHT: 'R',
  STOP: 'S',
  INTRO: 'I',
  USES: 'U',
  HAND: 'H',
  SPEAK: 'T', // Text-to-speech prefix, followed by the text
};

export function useBluetooth() {
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [error, setError] = useState<string | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: '0',
      timestamp: new Date(),
      type: 'info',
      message: 'Veera Bot Control System initialized. Ready to connect.',
    },
  ]);

  const deviceRef = useRef<BluetoothDevice | null>(null);
  const characteristicRef = useRef<BluetoothRemoteGATTCharacteristic | null>(null);
  const serverRef = useRef<BluetoothRemoteGATTServer | null>(null);

  const addLog = useCallback((type: LogEntry['type'], message: string) => {
    setLogs((prev) => [
      {
        id: Date.now().toString() + Math.random(),
        timestamp: new Date(),
        type,
        message,
      },
      ...prev.slice(0, 99),
    ]);
  }, []);

  const isBluetoothAvailable = useCallback((): boolean => {
    return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
  }, []);

  const connect = useCallback(async () => {
    if (!isBluetoothAvailable()) {
      const msg =
        'Web Bluetooth is not supported in this browser. Please use Chrome or Edge on desktop/Android.';
      setError(msg);
      setStatus('error');
      addLog('error', msg);
      return;
    }

    try {
      setStatus('connecting');
      setError(null);
      addLog('info', 'Scanning for Veera Bot robot via Bluetooth...');

      const device = await (navigator as any).bluetooth.requestDevice({
        filters: [{ name: ROBOT_DEVICE_NAME }],
        optionalServices: [ESP32_SERVICE_UUID],
      });

      addLog('info', `Device found: ${device.name}. Connecting to GATT server...`);
      deviceRef.current = device;

      device.addEventListener('gattserverdisconnected', () => {
        setStatus('disconnected');
        characteristicRef.current = null;
        serverRef.current = null;
        addLog('error', 'Robot disconnected unexpectedly. Please reconnect.');
        setError('Robot disconnected. Press RECONNECT to restore connection.');
      });

      const server = await device.gatt!.connect();
      serverRef.current = server;
      addLog('info', 'GATT server connected. Discovering services...');

      const service = await server.getPrimaryService(ESP32_SERVICE_UUID);
      addLog('info', 'Service discovered. Binding characteristic...');

      const characteristic = await service.getCharacteristic(ESP32_CHARACTERISTIC_UUID);
      characteristicRef.current = characteristic;

      setStatus('connected');
      addLog('info', `✓ Successfully connected to ${device.name}! Robot is ready for commands.`);
      setError(null);
    } catch (err: any) {
      const msg = err?.message || 'Failed to connect to robot';
      setStatus('error');
      setError(msg.includes('User cancelled')
        ? 'Connection cancelled by user.'
        : `Connection failed: ${msg}`);
      addLog('error', `Connection error: ${msg}`);
    }
  }, [isBluetoothAvailable, addLog]);

  const disconnect = useCallback(async () => {
    if (deviceRef.current?.gatt?.connected) {
      deviceRef.current.gatt.disconnect();
    }
    characteristicRef.current = null;
    serverRef.current = null;
    setStatus('disconnected');
    setError(null);
    addLog('info', 'Robot disconnected manually.');
  }, [addLog]);

  const reconnect = useCallback(async () => {
    if (serverRef.current && deviceRef.current) {
      try {
        setStatus('connecting');
        addLog('info', 'Attempting to reconnect...');
        const server = await deviceRef.current.gatt!.connect();
        serverRef.current = server;
        const service = await server.getPrimaryService(ESP32_SERVICE_UUID);
        const characteristic = await service.getCharacteristic(ESP32_CHARACTERISTIC_UUID);
        characteristicRef.current = characteristic;
        setStatus('connected');
        setError(null);
        addLog('info', '✓ Reconnected successfully!');
      } catch (err: any) {
        setStatus('error');
        setError(`Reconnection failed: ${err?.message}`);
        addLog('error', `Reconnect failed: ${err?.message}`);
      }
    } else {
      await connect();
    }
  }, [connect, addLog]);

  const sendCommand = useCallback(
    async (command: RobotCommand, text?: string): Promise<boolean> => {
      if (!characteristicRef.current || status !== 'connected') {
        addLog('error', `Cannot send "${command}": Robot not connected.`);
        return false;
      }

      try {
        let payload = COMMAND_MAP[command];
        if (command === 'SPEAK' && text) {
          payload = `T:${text}`;
        }

        const encoder = new TextEncoder();
        const data = encoder.encode(payload);
        await characteristicRef.current.writeValue(data);

        addLog('command', `→ Sent: ${command}${text ? ` ["${text.substring(0, 40)}${text.length > 40 ? '...' : ''}"]` : ''}`);
        return true;
      } catch (err: any) {
        addLog('error', `Command "${command}" failed: ${err?.message}`);
        if (err?.message?.includes('disconnected') || err?.message?.includes('GATT')) {
          setStatus('disconnected');
          setError('Robot disconnected. Please reconnect.');
        }
        return false;
      }
    },
    [status, addLog]
  );

  const clearLogs = useCallback(() => {
    setLogs([{ id: 'cleared', timestamp: new Date(), type: 'info', message: 'Log cleared.' }]);
  }, []);

  return {
    status,
    error,
    logs,
    isBluetoothAvailable: isBluetoothAvailable(),
    connect,
    disconnect,
    reconnect,
    sendCommand,
    clearLogs,
  };
}
