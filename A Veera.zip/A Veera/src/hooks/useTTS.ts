import { useState, useCallback, useRef } from 'react';

export function useTTS() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const isTTSAvailable = typeof window !== 'undefined' && 'speechSynthesis' in window;

  const speak = useCallback((text: string, rate = 0.95, pitch = 0.85, volume = 1.0) => {
    if (!isTTSAvailable) return;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate;
    utterance.pitch = pitch;
    utterance.volume = volume;

    // Try to find a robotic-ish voice
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(
      (v) =>
        v.name.toLowerCase().includes('google') ||
        v.name.toLowerCase().includes('david') ||
        v.name.toLowerCase().includes('mark') ||
        v.lang === 'en-US'
    );
    if (preferred) utterance.voice = preferred;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [isTTSAvailable]);

  const stopSpeaking = useCallback(() => {
    if (isTTSAvailable) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, [isTTSAvailable]);

  return { speak, stopSpeaking, isSpeaking, isTTSAvailable };
}
