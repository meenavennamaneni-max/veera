import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Square } from 'lucide-react';
import type { RobotCommand } from '../types/robot';

interface MovementControlsProps {
  isConnected: boolean;
  onCommand: (cmd: RobotCommand) => void;
  activeCmd: RobotCommand | null;
}

export default function MovementControls({ isConnected, onCommand, activeCmd }: MovementControlsProps) {

  const dirBtn = (
    cmd: RobotCommand,
    label: string,
    Icon: React.ComponentType<{ size?: number }>,
    colorClass: string,
    activeColorClass: string,
    glowColor: string
  ) => {
    const isActive = activeCmd === cmd;
    const isStop = cmd === 'STOP';
    return (
      <button
        onMouseDown={() => isConnected && onCommand(cmd)}
        onTouchStart={(e) => { e.preventDefault(); if (isConnected) onCommand(cmd); }}
        disabled={!isConnected}
        className={`
          btn-control relative flex flex-col items-center justify-center gap-1.5 rounded-xl border-2 font-bold transition-all duration-150
          ${isStop ? 'py-5 col-span-1' : 'py-5'}
          ${!isConnected
            ? 'border-gray-800 bg-gray-900/30 text-gray-700 cursor-not-allowed'
            : isActive
            ? `${activeColorClass} scale-95`
            : `${colorClass} cursor-pointer`
          }
        `}
        style={isActive && isConnected ? { boxShadow: `0 0 18px ${glowColor}, 0 0 35px ${glowColor}40` } : {}}
      >
        {/* Glow pulse when active */}
        {isActive && isConnected && (
          <div
            className="absolute inset-0 rounded-xl opacity-20 animate-ping"
            style={{ background: glowColor }}
          />
        )}
        <Icon size={isStop ? 20 : 22} />
        <span className="text-xs font-mono tracking-widest leading-none">{label}</span>
      </button>
    );
  };

  return (
    <div className="glass-panel rounded-xl p-4 space-y-3 panel-corners">
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-yellow-500/10 pb-3">
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-yellow-400" style={{ boxShadow: '0 0 6px rgba(255,215,0,0.8)' }} />
          <span className="text-yellow-400 text-sm font-bold tracking-widest uppercase font-mono">
            Movement Control
          </span>
        </div>
        <span className={`ml-auto text-xs font-mono px-2 py-0.5 rounded-full border ${
          isConnected ? 'text-green-400 border-green-500/30 bg-green-500/10' : 'text-gray-600 border-gray-700 bg-gray-800/30'
        }`}>
          {isConnected ? 'ACTIVE' : 'OFFLINE'}
        </span>
      </div>

      {/* D-Pad grid */}
      <div
        className="grid gap-2 mx-auto"
        style={{
          display: 'grid',
          gridTemplateAreas: `". forward ." "left stop right" ". back ."`,
          gridTemplateColumns: '1fr 1.2fr 1fr',
          gridTemplateRows: 'auto auto auto',
          maxWidth: '280px',
        }}
      >
        {/* Forward */}
        <div style={{ gridArea: 'forward' }}>
          {dirBtn('FORWARD', 'FWD', ArrowUp,
            'border-yellow-500/35 bg-yellow-500/8 text-yellow-300 hover:bg-yellow-500/18 hover:border-yellow-400/60',
            'border-yellow-400 bg-yellow-500/25 text-yellow-200',
            '#FFD700'
          )}
        </div>

        {/* Left */}
        <div style={{ gridArea: 'left' }}>
          {dirBtn('LEFT', 'LEFT', ArrowLeft,
            'border-blue-500/35 bg-blue-500/8 text-blue-300 hover:bg-blue-500/18 hover:border-blue-400/60',
            'border-blue-400 bg-blue-500/25 text-blue-200',
            '#60a5fa'
          )}
        </div>

        {/* Stop — center */}
        <div style={{ gridArea: 'stop' }}>
          {dirBtn('STOP', 'STOP', Square,
            'border-red-500/50 bg-red-500/12 text-red-300 hover:bg-red-500/22 hover:border-red-400/70',
            'border-red-400 bg-red-500/28 text-red-200',
            '#f87171'
          )}
        </div>

        {/* Right */}
        <div style={{ gridArea: 'right' }}>
          {dirBtn('RIGHT', 'RIGHT', ArrowRight,
            'border-blue-500/35 bg-blue-500/8 text-blue-300 hover:bg-blue-500/18 hover:border-blue-400/60',
            'border-blue-400 bg-blue-500/25 text-blue-200',
            '#60a5fa'
          )}
        </div>

        {/* Back */}
        <div style={{ gridArea: 'back' }}>
          {dirBtn('BACK', 'BACK', ArrowDown,
            'border-yellow-500/35 bg-yellow-500/8 text-yellow-300 hover:bg-yellow-500/18 hover:border-yellow-400/60',
            'border-yellow-400 bg-yellow-500/25 text-yellow-200',
            '#FFD700'
          )}
        </div>
      </div>

      {/* Command info */}
      <div className="flex items-center justify-center gap-2">
        <div className="h-px flex-1 bg-gray-800" />
        <p className="text-xs text-gray-600 font-mono px-2">
          {isConnected
            ? activeCmd
              ? `EXECUTING: ${activeCmd}`
              : 'TAP TO SEND COMMAND'
            : 'CONNECT ROBOT TO ENABLE'
          }
        </p>
        <div className="h-px flex-1 bg-gray-800" />
      </div>
    </div>
  );
}
