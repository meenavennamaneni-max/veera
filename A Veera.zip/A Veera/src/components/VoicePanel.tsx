import { useState, useRef } from 'react';
import { MessageSquare, Send, Trash2, Volume2, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import type { VoiceHistoryEntry } from '../types/robot';

interface VoicePanelProps {
  isConnected: boolean;
  isSpeaking: boolean;
  history: VoiceHistoryEntry[];
  onSpeak: (text: string) => void;
  onClearHistory: () => void;
}

const MAX_CHARS = 300;

const typeColors: Record<VoiceHistoryEntry['type'], string> = {
  custom: 'text-yellow-400 border-yellow-500/30',
  intro: 'text-purple-400 border-purple-500/30',
  uses: 'text-cyan-400 border-cyan-500/30',
  system: 'text-gray-400 border-gray-600/30',
};

const typeBadges: Record<VoiceHistoryEntry['type'], string> = {
  custom: 'CUSTOM',
  intro: 'INTRO',
  uses: 'USES',
  system: 'SYSTEM',
};

const typeBadgeColors: Record<VoiceHistoryEntry['type'], string> = {
  custom: 'bg-yellow-500/15 text-yellow-400',
  intro: 'bg-purple-500/15 text-purple-400',
  uses: 'bg-cyan-500/15 text-cyan-400',
  system: 'bg-gray-700 text-gray-400',
};

export default function VoicePanel({ isConnected, isSpeaking, history, onSpeak, onClearHistory }: VoicePanelProps) {
  const [text, setText] = useState('');
  const [showHistory, setShowHistory] = useState(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSpeak = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    onSpeak(trimmed);
    setText('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleSpeak();
    }
  };

  const handleTextareaInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    if (val.length <= MAX_CHARS) {
      setText(val);
      // Auto-resize
      e.target.style.height = 'auto';
      e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px';
    }
  };

  const remaining = MAX_CHARS - text.length;

  return (
    <div className="glass-panel rounded-xl p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-yellow-500/10 pb-3">
        <MessageSquare size={16} className="text-yellow-400" />
        <span className="text-yellow-400 text-sm font-bold tracking-widest uppercase font-mono">
          Voice Message
        </span>
        {isSpeaking && (
          <span className="ml-auto flex items-center gap-1 text-xs text-yellow-400 font-mono animate-pulse">
            <Volume2 size={12} />
            TRANSMITTING
          </span>
        )}
      </div>

      {/* Text input area */}
      <div className="space-y-2">
        <div
          className={`relative rounded-lg border-2 transition-all duration-200 ${
            text.length > 0
              ? 'border-yellow-500/40 bg-yellow-500/5'
              : 'border-gray-700 bg-black/20'
          }`}
        >
          <textarea
            ref={textareaRef}
            value={text}
            onChange={handleTextareaInput}
            onKeyDown={handleKeyDown}
            placeholder="Type a custom message for the robot to speak..."
            disabled={!isConnected}
            rows={3}
            className="w-full bg-transparent px-4 pt-3 pb-8 text-white placeholder-gray-600 resize-none focus:outline-none font-mono text-sm leading-relaxed disabled:text-gray-600 disabled:cursor-not-allowed"
            style={{ minHeight: '88px', maxHeight: '160px' }}
          />
          {/* Bottom bar with char count */}
          <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between px-3 py-1.5 border-t border-gray-700/50 rounded-b-lg bg-black/10">
            <span className="text-xs text-gray-600 font-mono">Ctrl+Enter to send</span>
            <span className={`text-xs font-mono ${remaining < 50 ? 'text-orange-400' : 'text-gray-600'}`}>
              {remaining} / {MAX_CHARS}
            </span>
          </div>
        </div>

        {/* Quick phrase buttons */}
        <div className="flex flex-wrap gap-1.5">
          {['Hello!', 'I am ready.', 'Task complete.', 'Scanning area.', 'Battery low.'].map((phrase) => (
            <button
              key={phrase}
              onClick={() => setText(phrase)}
              disabled={!isConnected}
              className="px-2.5 py-1 rounded text-xs font-mono text-gray-400 border border-gray-700 bg-gray-800/50 hover:border-yellow-500/40 hover:text-yellow-400 hover:bg-yellow-500/5 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            >
              {phrase}
            </button>
          ))}
        </div>

        {/* Speak button */}
        <button
          onClick={handleSpeak}
          disabled={!isConnected || !text.trim() || isSpeaking}
          className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm tracking-wider transition-all btn-control
            ${isConnected && text.trim() && !isSpeaking
              ? 'bg-yellow-500 hover:bg-yellow-400 text-black border border-yellow-400 glow-yellow-sm cursor-pointer'
              : 'bg-gray-800/50 border border-gray-700 text-gray-500 cursor-not-allowed'
            }`}
        >
          {isSpeaking ? (
            <>
              <Volume2 size={18} className="animate-pulse" />
              ROBOT IS SPEAKING...
            </>
          ) : (
            <>
              <Send size={18} />
              SPEAK MESSAGE
            </>
          )}
        </button>
      </div>

      {/* History section */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowHistory((v) => !v)}
            className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-gray-200 transition-colors font-mono"
          >
            <Clock size={12} />
            VOICE HISTORY ({history.length})
            {showHistory ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
          {history.length > 0 && (
            <button
              onClick={onClearHistory}
              className="ml-auto flex items-center gap-1 text-xs text-gray-600 hover:text-red-400 transition-colors"
            >
              <Trash2 size={11} />
              Clear
            </button>
          )}
        </div>

        {showHistory && (
          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {history.length === 0 ? (
              <div className="text-center py-4 text-gray-600 text-xs font-mono">
                No voice messages yet
              </div>
            ) : (
              history.map((entry) => (
                <div
                  key={entry.id}
                  className={`px-3 py-2 rounded-lg border bg-black/20 slide-in ${typeColors[entry.type]}`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs px-1.5 py-0.5 rounded font-mono font-bold ${typeBadgeColors[entry.type]}`}>
                      {typeBadges[entry.type]}
                    </span>
                    <span className="text-xs text-gray-600 font-mono">
                      {entry.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>
                    <button
                      onClick={() => {
                        if (entry.type === 'custom') setText(entry.text);
                      }}
                      className="ml-auto text-xs text-gray-600 hover:text-gray-400 transition-colors"
                      title="Reuse this message"
                    >
                      ↺
                    </button>
                  </div>
                  <p className="text-xs text-gray-300 font-mono leading-relaxed line-clamp-3">
                    {entry.text}
                  </p>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
