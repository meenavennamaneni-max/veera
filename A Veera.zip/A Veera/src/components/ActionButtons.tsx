import { Info, List, Hand, Volume2, VolumeX, Loader2 } from 'lucide-react';
import type { RobotCommand } from '../types/robot';

interface ActionButtonsProps {
  isConnected: boolean;
  isSpeaking: boolean;
  onCommand: (cmd: RobotCommand) => void;
  onIntroduction: () => void;
  onUses: () => void;
  onHandMovement: () => void;
  onStopSpeaking: () => void;
  activeAction: string | null;
}

interface ActionBtn {
  id: string;
  label: string;
  sublabel: string;
  Icon: React.ComponentType<{ size?: number; className?: string }>;
  color: string;
  activeColor: string;
  handler: string;
}

const actions: ActionBtn[] = [
  {
    id: 'intro',
    label: 'INTRODUCTION',
    sublabel: 'Robot self-intro',
    Icon: Info,
    color: 'border-purple-500/40 bg-purple-500/10 text-purple-300 hover:bg-purple-500/20 hover:border-purple-400',
    activeColor: 'border-purple-400 bg-purple-500/25 text-purple-200',
    handler: 'intro',
  },
  {
    id: 'uses',
    label: 'USES',
    sublabel: 'What I can do',
    Icon: List,
    color: 'border-cyan-500/40 bg-cyan-500/10 text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-400',
    activeColor: 'border-cyan-400 bg-cyan-500/25 text-cyan-200',
    handler: 'uses',
  },
  {
    id: 'hand',
    label: 'HAND MOVEMENT',
    sublabel: 'Activate arms',
    Icon: Hand,
    color: 'border-orange-500/40 bg-orange-500/10 text-orange-300 hover:bg-orange-500/20 hover:border-orange-400',
    activeColor: 'border-orange-400 bg-orange-500/25 text-orange-200',
    handler: 'hand',
  },
];

export default function ActionButtons({
  isConnected,
  isSpeaking,
  onIntroduction,
  onUses,
  onHandMovement,
  onStopSpeaking,
  activeAction,
}: ActionButtonsProps) {
  const handlers: Record<string, () => void> = {
    intro: onIntroduction,
    uses: onUses,
    hand: onHandMovement,
  };

  return (
    <div className="glass-panel rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2 border-b border-yellow-500/10 pb-3">
        <Volume2 size={16} className="text-yellow-400" />
        <span className="text-yellow-400 text-sm font-bold tracking-widest uppercase font-mono">
          Robot Actions
        </span>
        {isSpeaking && (
          <div className="ml-auto flex items-center gap-1.5">
            <div className="flex items-end gap-0.5">
              {[3,5,4,6,3].map((h,i) => (
                <div
                  key={i}
                  className="bg-yellow-400 rounded-sm"
                  style={{
                    width: '3px',
                    height: `${h}px`,
                    animation: `pulse ${0.3 + i*0.1}s ease-in-out infinite alternate`,
                  }}
                />
              ))}
            </div>
            <span className="text-xs text-yellow-400 font-mono animate-pulse">SPEAKING</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 gap-2">
        {actions.map(({ id, label, sublabel, Icon, color, activeColor, handler }) => {
          const isActive = activeAction === id;
          return (
            <button
              key={id}
              onClick={() => isConnected && handlers[handler]()}
              disabled={!isConnected}
              className={`
                btn-control w-full flex items-center gap-4 px-4 py-3.5 rounded-xl border-2
                font-bold transition-all duration-200 text-left
                ${!isConnected
                  ? 'border-gray-700 bg-gray-800/30 text-gray-600 cursor-not-allowed'
                  : isActive
                  ? activeColor
                  : color
                }
              `}
            >
              <div className={`p-2 rounded-lg ${isActive ? 'bg-white/10' : 'bg-black/20'}`}>
                {isActive ? (
                  <Loader2 size={20} className="animate-spin" />
                ) : (
                  <Icon size={20} />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-bold tracking-wider font-mono">{label}</div>
                <div className="text-xs opacity-60 font-normal mt-0.5">{sublabel}</div>
              </div>
              {isActive && (
                <div className="w-2 h-2 rounded-full bg-current animate-pulse" />
              )}
            </button>
          );
        })}
      </div>

      {/* Stop speaking */}
      {isSpeaking && (
        <button
          onClick={onStopSpeaking}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-red-600/40 bg-red-900/20 text-red-400 hover:bg-red-900/30 text-sm font-bold tracking-wider transition-all btn-control"
        >
          <VolumeX size={16} />
          STOP SPEAKING
        </button>
      )}
    </div>
  );
}
