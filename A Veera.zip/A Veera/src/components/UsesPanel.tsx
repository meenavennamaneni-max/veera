import { List, Volume2, ChevronRight } from 'lucide-react';

interface UsesPanelProps {
  isConnected: boolean;
  isSpeaking: boolean;
  onSpeak: (text: string) => void;
  onClose: () => void;
}

const USES_TEXT = `Veera Bot is a multifunctional autonomous robot designed for personal assistance, education, and entertainment. 
Here is what I can do: 
First, Navigation — I can move forward, backward, left, and right using my motorized wheels. 
Second, Voice Communication — I can speak custom messages, greet visitors, and deliver announcements through my built-in speaker. 
Third, Arm Control — My robotic arms can wave, gesture, and perform programmed movement sequences. 
Fourth, Environment Interaction — I can interact with objects within my reach using my articulated hands. 
Fifth, Remote Control — I can be fully controlled via Bluetooth from any device running this control dashboard. 
Sixth, Autonomous Routines — I can execute pre-programmed sequences for demonstrations and events.`;

const capabilities = [
  {
    icon: '🚗',
    title: 'Navigation',
    desc: 'Omnidirectional movement — forward, back, left, right with precision motor control',
    color: 'border-yellow-500/30 bg-yellow-500/5',
    tag: 'MOTOR',
    tagColor: 'bg-yellow-500/15 text-yellow-400',
  },
  {
    icon: '🔊',
    title: 'Voice Communication',
    desc: 'Custom TTS messages, greetings, announcements via onboard speaker',
    color: 'border-purple-500/30 bg-purple-500/5',
    tag: 'AUDIO',
    tagColor: 'bg-purple-500/15 text-purple-400',
  },
  {
    icon: '🦾',
    title: 'Arm Control',
    desc: 'Robotic arm actuation — wave, gesture, and perform programmed sequences',
    color: 'border-orange-500/30 bg-orange-500/5',
    tag: 'SERVO',
    tagColor: 'bg-orange-500/15 text-orange-400',
  },
  {
    icon: '📡',
    title: 'Remote Control',
    desc: 'Full Bluetooth BLE control via ESP32 — range up to 10 meters',
    color: 'border-cyan-500/30 bg-cyan-500/5',
    tag: 'BLE',
    tagColor: 'bg-cyan-500/15 text-cyan-400',
  },
  {
    icon: '🤖',
    title: 'Autonomous Routines',
    desc: 'Pre-programmed demo sequences for events, exhibitions, and presentations',
    color: 'border-green-500/30 bg-green-500/5',
    tag: 'AUTO',
    tagColor: 'bg-green-500/15 text-green-400',
  },
  {
    icon: '🎓',
    title: 'Education & Demo',
    desc: 'Interactive demonstrations for STEM education and robotics learning',
    color: 'border-blue-500/30 bg-blue-500/5',
    tag: 'EDU',
    tagColor: 'bg-blue-500/15 text-blue-400',
  },
];

export default function UsesPanel({ isConnected, isSpeaking, onSpeak, onClose }: UsesPanelProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}>
      <div className="glass-panel-bright rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col border border-yellow-500/30" style={{ boxShadow: '0 0 60px rgba(255,215,0,0.15), 0 0 120px rgba(255,215,0,0.05)' }}>
        {/* Header */}
        <div className="flex items-center gap-3 px-6 py-4 border-b border-yellow-500/20 shrink-0">
          <div className="p-2 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
            <List size={20} className="text-yellow-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white tracking-wider font-mono">ROBOT CAPABILITIES</h2>
            <p className="text-xs text-gray-500 font-mono">What VEERA BOT can do</p>
          </div>
          <button
            onClick={onClose}
            className="ml-auto p-2 rounded-lg border border-gray-700 text-gray-400 hover:text-white hover:border-gray-500 transition-all text-xl leading-none font-mono"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto flex-1 p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {capabilities.map((cap, i) => (
              <div
                key={i}
                className={`rounded-xl border p-4 ${cap.color} transition-all hover:scale-[1.01]`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{cap.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-white text-sm">{cap.title}</h3>
                      <span className={`text-xs px-1.5 py-0.5 rounded font-mono font-bold ${cap.tagColor}`}>
                        {cap.tag}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed">{cap.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Specs row */}
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'HEIGHT', value: '2 feet' },
              { label: 'CONTROLLER', value: 'ESP32' },
              { label: 'WIRELESS', value: 'BLE 4.2' },
              { label: 'POWER', value: 'Li-Ion' },
            ].map(({ label, value }) => (
              <div key={label} className="bg-black/30 rounded-lg px-3 py-2 text-center">
                <div className="text-xs text-gray-500 font-mono">{label}</div>
                <div className="text-sm font-bold text-yellow-400 font-mono mt-0.5">{value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-yellow-500/10 flex flex-col sm:flex-row gap-3 shrink-0">
          <button
            onClick={() => onSpeak(USES_TEXT)}
            disabled={!isConnected || isSpeaking}
            className={`flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-sm tracking-wider transition-all btn-control
              ${isConnected && !isSpeaking
                ? 'bg-yellow-500 hover:bg-yellow-400 text-black glow-yellow-sm cursor-pointer'
                : 'bg-gray-800 border border-gray-700 text-gray-500 cursor-not-allowed'
              }`}
          >
            <Volume2 size={16} />
            {isSpeaking ? 'SPEAKING...' : 'SPEAK CAPABILITIES'}
          </button>
          <button
            onClick={onClose}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-sm tracking-wider border border-gray-700 text-gray-300 hover:border-gray-500 hover:text-white transition-all btn-control"
          >
            CLOSE
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
